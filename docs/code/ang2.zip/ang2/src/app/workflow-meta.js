"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var WorkflowMeta = (function () {
    function WorkflowMeta() {
    }
    return WorkflowMeta;
}());
exports.WorkflowMeta = WorkflowMeta;
