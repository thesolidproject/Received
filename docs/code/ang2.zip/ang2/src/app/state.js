"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var State = (function () {
    function State() {
    }
    return State;
}());
exports.State = State;
